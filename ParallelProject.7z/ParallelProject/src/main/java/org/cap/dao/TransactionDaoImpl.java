package org.cap.dao;

import org.springframework.stereotype.Repository;

@Repository("transactionDaoImpl")
public class TransactionDaoImpl implements TransactionDao{

}
