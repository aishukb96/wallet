package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.cap.model.Customer;
import org.springframework.stereotype.Repository;

@Repository("customerDaoImpl")
public class CustomerDaoImpl implements CustomerDao{

	@PersistenceContext(type=PersistenceContextType.EXTENDED)
	private EntityManager entityManager;
	
	@Override
	public boolean validateLogin(int customerId, String customerPassword) {
		// TODO Auto-generated method stub
		Query query
		= entityManager.createQuery("from Customer where customerId=? and customerPassword=?");
		query.setParameter(0, customerId);
		query.setParameter(1, customerPassword);
		List<Customer> customers= query.getResultList();
		if(!customers.isEmpty())
			return true;
		return false;
	}

	@Override
	public String getCustomerName(int customerId) {
		// TODO Auto-generated method stub
		Query query
		= entityManager.createQuery("select cust.firstName from Customer cust where cust.customerId=?");
		query.setParameter(0, customerId);
		List<String> customers= query.getResultList();
		return customers.get(0);
	}

}
