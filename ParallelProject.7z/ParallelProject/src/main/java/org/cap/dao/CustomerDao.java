package org.cap.dao;

public interface CustomerDao {
	public boolean validateLogin(int customerId, String customerPassword);
	public String getCustomerName(int customerId);
}
