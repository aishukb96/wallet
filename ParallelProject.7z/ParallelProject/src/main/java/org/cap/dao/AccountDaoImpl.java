package org.cap.dao;



import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.cap.model.Account;
import org.cap.model.Transaction;
import org.springframework.stereotype.Repository;

@Repository("accountDaoImpl")
public class AccountDaoImpl implements AccountDao{

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void createAccount(Account account) {
		// TODO Auto-generated method stub
		Query query= entityManager.createQuery("select max(accountNo) from Account");
		List<Long> max= query.getResultList();
		account.setAccountNo(max.get(0)+1);
		System.out.println(account);
		entityManager.persist(account);
		
	}

	@Override
	public List<Account> getAllAccounts(int customerId) {
		// TODO Auto-generated method stub
		Query query= entityManager
				.createQuery("from Account acc where acc.customer.customerId=:custId");
			
			query.setParameter("custId", customerId);
			
			List<Account> accounts= query.getResultList();
			
			
			return accounts;
	}
	

	@Transactional()
	public Map<List<Account>, Double> getAmountCrDe(String strQuery, int customerId) {
					
	Query query2=entityManager.createQuery(strQuery);
	query2.setParameter("custId", customerId);
	List<Transaction> transactions=query2.getResultList();
	Map<List<Account>, Double> map=transactions.stream().collect(Collectors.groupingBy(Transaction::getFromAccount,Collectors.summingDouble(Transaction::getAmount)));
	return map;
		}	

}
