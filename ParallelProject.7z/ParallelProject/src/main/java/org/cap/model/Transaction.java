package org.cap.model;

import java.util.Date;
import java.util.List;

import javax.persistence.GenerationType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Transaction {
	
	@ManyToOne(targetEntity=Customer.class)
	@JoinColumn(name="customerId")
	private List<Customer> customers;

@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int transactionId;

private Date transactionDate;
private String transactionType;

@ManyToOne(targetEntity=Account.class)
private List<Account> fromAccountNo;
private List<Account> toAccountNo;
private double amount;
private String description;
private String status;

@OneToMany
private Transaction transaction;
public List<Customer> getCustomers() {
	return customers;
}
public void setCustomers(List<Customer> customers) {
	this.customers = customers;
}
public int getTransactionId() {
	return transactionId;
}
public void setTransactionId(int transactionId) {
	this.transactionId = transactionId;
}
public Date getTransactionDate() {
	return transactionDate;
}
public void setTransactionDate(Date transactionDate) {
	this.transactionDate = transactionDate;
}
public String getTransactionType() {
	return transactionType;
}
public void setTransactionType(String transactionType) {
	this.transactionType = transactionType;
}
public List<Account> getFromAccountNo() {
	return fromAccountNo;
}
public void setFromAccountNo(List<Account> fromAccountNo) {
	this.fromAccountNo = fromAccountNo;
}
public List<Account> getToAccountNo() {
	return toAccountNo;
}
public void setToAccountNo(List<Account> toAccountNo) {
	this.toAccountNo = toAccountNo;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
@Override
public String toString() {
	return "Transaction [customers=" + customers + ", transactionId=" + transactionId + ", transactionDate="
			+ transactionDate + ", transactionType=" + transactionType + ", fromAccountNo=" + fromAccountNo
			+ ", toAccountNo=" + toAccountNo + ", amount=" + amount + ", description=" + description + ", status="
			+ status + "]";
}
public Transaction(List<Customer> customers, int transactionId, Date transactionDate, String transactionType,
		List<Account> fromAccountNo, List<Account> toAccountNo, double amount, String description, String status) {
	super();
	this.customers = customers;
	this.transactionId = transactionId;
	this.transactionDate = transactionDate;
	this.transactionType = transactionType;
	this.fromAccountNo = fromAccountNo;
	this.toAccountNo = toAccountNo;
	this.amount = amount;
	this.description = description;
	this.status = status;
}
public Transaction() {
	super();
}
 

}
