package org.cap.model;

import java.util.Date;

import javax.persistence.GenerationType;
@Entity
public class Customer {

@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private long customerId;
private String customerPassword;
private String status;
private Date lastLoginDate;
private String firstName;
private String lastName;
private String email;
private String mobile;

@OneToMany(targetEntity=)
private Account account;
public long getCustomerId() {
	return customerId;
}
public void setCustomerId(long customerId) {
	this.customerId = customerId;
}
public String getCustomerPassword() {
	return customerPassword;
}
public void setCustomerPassword(String customerPassword) {
	this.customerPassword = customerPassword;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public Date getLastLoginDate() {
	return lastLoginDate;
}
public void setLastLoginDate(Date lastLoginDate) {
	this.lastLoginDate = lastLoginDate;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getMobile() {
	return mobile;
}
public void setMobile(String mobile) {
	this.mobile = mobile;
}
@Override
public String toString() {
	return "LoginTable [customerId=" + customerId + ", customerPassword=" + customerPassword + ", status=" + status
			+ ", lastLoginDate=" + lastLoginDate + ", firstName=" + firstName + ", lastName=" + lastName + ", email="
			+ email + ", mobile=" + mobile + "]";
}
public Customer(long customerId, String customerPassword, String status, Date lastLoginDate, String firstName,
		String lastName, String email, String mobile) {
	super();
	this.customerId = customerId;
	this.customerPassword = customerPassword;
	this.status = status;
	this.lastLoginDate = lastLoginDate;
	this.firstName = firstName;
	this.lastName = lastName;
	this.email = email;
	this.mobile = mobile;
}
public Customer() {
	super();
}



}
