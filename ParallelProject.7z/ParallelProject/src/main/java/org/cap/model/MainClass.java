package org.cap.model;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {
public static void main(String[] args)
{
	EntityManagerFactory factory=
			Persistence.createEntityManagerFactory("jpademo");
	EntityManager entityManager=factory.createEntityManager();
	
	EntityTransaction transaction= entityManager.getTransaction();
	
	transaction.begin();
	Customer customer=new Customer();
	customer.setCustomerPassword("tom123");
	customer.setFirstName("Tom");
	customer.setLastName("Jerry");
	customer.setLastLoginDate(new Date());
	
	Account account=new Account();
	account.setAccountNo(100001);
	account.setAccountType("Savings");
	
	account.setCustomer(customer);
	
	Account account1=new Account();
	account1.setAccountNo(100002);
	account1.setAccountType("Current");
	
	account1.setCustomer(customer);
	
	entityManager.persist(customer);
	entityManager.persist(account);
	entityManager.persist(account1);
	
	transaction.commit();
}
}
