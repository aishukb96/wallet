package org.cap.model;

import java.util.Date;
import java.util.List;

import javax.persistence.GenerationType;
import javax.persistence.ManyToOne;

@Entity
public class Account {
	
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int accountId;
private long accountNo;
private String accountType;
private double openingBalance;
private Date openingDate;

@ManyToOne(targetEntity=Customer.class)
@JoinColumn(name="customerId")
private List<Customer> customers;
private String status;

@OneToMany(targetEntity=Account.class,mappedBy="fromAccount")
private Transaction fromTransaction;

@OneToMany(targetEntity=Account.class,mappedBy="toAccount")
private Transaction toTransaction;
public int getAccountId() {
	return accountId;
}
public void setAccountId(int accountId) {
	this.accountId = accountId;
}
public long getAccountNo() {
	return accountNo;
}
public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public double getOpeningBalance() {
	return openingBalance;
}
public void setOpeningBalance(double openingBalance) {
	this.openingBalance = openingBalance;
}
public Date getOpeningDate() {
	return openingDate;
}
public void setOpeningDate(Date openingDate) {
	this.openingDate = openingDate;
}
public List<Customer> getLoginTables() {
	return customers;
}
public void setLoginTables(List<Customer> customers) {
	this.customers = customers;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
@Override
public String toString() {
	return "Account [accountId=" + accountId + ", accountNo=" + accountNo + ", accountType=" + accountType
			+ ", openingBalance=" + openingBalance + ", openingDate=" + openingDate + ", loginTables=" + customers
			+ ", status=" + status + "]";
}
public Account(int accountId, long accountNo, String accountType, double openingBalance, Date openingDate,
		List<Customer> customers, String status) {
	super();
	this.accountId = accountId;
	this.accountNo = accountNo;
	this.accountType = accountType;
	this.openingBalance = openingBalance;
	this.openingDate = openingDate;
	this.customers = customers;
	this.status = status;
}
public Account() {
	super();
}


}
