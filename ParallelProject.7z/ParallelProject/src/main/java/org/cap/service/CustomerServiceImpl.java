package org.cap.service;

import org.cap.dao.CustomerDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository("customerServiceImpl")
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	private CustomerDao customerDaoImpl;
	@Override
	public boolean validateLogin(int customerId, String customerPassword) {
		// TODO Auto-generated method stub
		return customerDaoImpl.validateLogin(customerId, customerPassword);
	}
	@Override
	public String getCustomerName(int customerId) {
		// TODO Auto-generated method stub
		return customerDaoImpl.getCustomerName(customerId);
	}

}
