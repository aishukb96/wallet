package org.cap.service;

import java.util.List;
import java.util.Map;

import org.cap.model.Account;

public interface AccountService {
	public void createAccount(Account account);
	public List<Account> getAllAccounts(int customerId);
	public Map<Account, Double> getAmountCrDe(String strQuery,int customerId);

}
