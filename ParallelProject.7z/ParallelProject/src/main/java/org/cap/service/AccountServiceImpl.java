package org.cap.service;

import java.util.List;

import org.cap.dao.AccountDao;
import org.cap.model.Account;
import org.cap.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Repository("accountServiceImpl")
public class AccountServiceImpl implements AccountService{

	@Autowired
	private AccountDao accountDaoImpl;
	@Override
	public void createAccount(Account account) {
		// TODO Auto-generated method stub
		accountDaoImpl.createAccount(account);
	}
	@Override
	public List<Account> getAllAccounts(int customerId) {
		// TODO Auto-generated method stub
		return accountDaoImpl.getAllAccounts(customerId);
	}

	
}
