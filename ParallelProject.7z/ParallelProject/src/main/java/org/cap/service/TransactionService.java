package org.cap.service;

public interface TransactionService {

}
