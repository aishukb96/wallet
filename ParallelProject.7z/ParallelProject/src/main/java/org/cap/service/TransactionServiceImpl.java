package org.cap.service;

import org.springframework.stereotype.Repository;

@Repository("transactionServiceImpl")
public class TransactionServiceImpl implements TransactionService{

}
