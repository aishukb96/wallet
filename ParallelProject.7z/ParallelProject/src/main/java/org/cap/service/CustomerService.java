package org.cap.service;

public interface CustomerService {
	public boolean validateLogin(int customerId, String customerPassword);
	public String getCustomerName(int customerId);
}
