package com.wallet;

import com.bean.CustomerDetails;
import com.dao.WalletDao;
import com.dao.WalletDaoImpl;
import com.exception.*;

import junit.framework.TestCase;

/**
 * Unit test for simple App.
 */
public class AppTest extends TestCase
{
    WalletDao walletdao=new WalletDaoImpl();
    
  
    
    public void testShowBalance()
    {
    	try
    	{
    		CustomerDetails cd=walletdao.getEmployeeByPin(100001l, 1234);
    		assertNotNull(cd);
    		CustomerDetails dd=walletdao.getEmployeeByPin(100009l, 1234);
    		assertNull(dd);
    	}catch(WalletException e)
    	{
    		System.out.println(e.getLocalizedMessage());
    	}
    }
    
    public void testDepositAmount()
    {
    	try
    	{
    		CustomerDetails cd=walletdao.getEmployeeByPin(100001l, 1234);
    		assertNotNull(cd);
    		CustomerDetails dd=walletdao.getEmployeeByPin(100008l, 1234);
    		assertNull(dd);
    	}catch(WalletException e)
    	{
    		System.out.println(e.getLocalizedMessage());
    	}
    }
    
}
