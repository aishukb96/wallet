package com.wallet;
import java.util.Scanner;

import com.bean.CustomerDetails;
import com.exception.WalletException;
import com.service.WalletService;
import com.service.WalletServiceImpl;
public class App 
{
	WalletService walletservice=new WalletServiceImpl();
	Scanner sc=new Scanner(System.in);
    public static void main( String[] args )
    {
       App app=new App();
       String option=null;
       while(true)
       {
    	   System.out.println("===========WALLET APPLICATION=========");
    	   System.out.println("1. Create Account");
    	   System.out.println("2. Show balance");
    	   System.out.println("3. Deposit amount");
    	   System.out.println("4. Withdraw amount");
    	   System.out.println("5. Transfer fund");
    	   System.out.println("6. Print transactions");
    	   System.out.println("7. Exit");
    	   option=app.sc.nextLine();
    	   switch(option)
    	   {
    	   case "1":app.createAccount();
    	   			break;
    	   case "2":app.showBalance();
    	   			break;
    	   case "3":app.depositAmount();
    	   			break;
    	   case "4":app.withdrawAmount();
    	   			break;
    	   case "5":app.transferFund();
    	   			break;
    	   case "6":app.printTransaction();
    	   			break;
    	   case "7":System.exit(0);
    	   }
       }
    }
    
    public void createAccount()
    {
    	CustomerDetails cd=new CustomerDetails();
    	System.out.println("Enter the name of the account holder");
    	cd.setName(sc.nextLine());
    	System.out.println("Enter the amount to be deposited in the account");
    	cd.setAccBalance(sc.nextDouble());
    	sc.nextLine();
    	System.out.println("Enter the mobile number");
    	cd.setMobileNumber(sc.nextLine());
    	System.out.println("Enter the address");
    	cd.setAddress(sc.nextLine());
    	System.out.println("Enter the 4 digit pin number");
    	cd.setPin(sc.nextDouble());
    	
    	try {
    		boolean result=walletservice.validateCustomer(cd);
    		if(result)
    		{
    			long id=walletservice.addCustomer(cd);
    			System.out.println("Customer with the account number "+ id+" has been created successfully");
    		}}catch(WalletException e)
    		{
    			System.out.println();
    			System.err.println("An error occured "+e.getMessage());
    			System.out.println();
    		}
    	
    }
    
    public void showBalance()
    {
    	System.out.println("Enter your account number");
    	Long accnum=sc.nextLong();
    	System.out.println("Enter the pin");
    	double pinn=sc.nextDouble();
    	try {
    		CustomerDetails ccd=walletservice.getEmployeeByPin(accnum, pinn);
    		System.out.println("The balance in your account is :"+ccd.getAccBalance());
    	}catch(WalletException e)
    	{
    		System.err.println("An error occurred : "+e.getMessage());
    	}
    }
    
    public void depositAmount()
    {
    	System.out.println("Enter your account number");
    	Long accnum=sc.nextLong();
    	System.out.println("Enter the pin");
    	double pinn=sc.nextDouble();
    	try {
    		CustomerDetails ccd=walletservice.getEmployeeByPin(accnum, pinn);
    		System.out.println("Enter the amount to be deposited");
    		double amt=sc.nextDouble();
    		double bal=ccd.getAccBalance();
    		System.out.println("The old balance in your account was :"+bal);
    		bal+=amt;
    		ccd.setAccBalance(bal);
    		System.out.println("The new balance in your account is :"+ccd.getAccBalance());
    	}catch(WalletException e)
    	{
    		System.err.println("An error occurred : "+e.getMessage());
    	}
    }
    
    
    public void withdrawAmount()
    {
    	System.out.println("Enter your account number");
    	Long accnum=sc.nextLong();
    	System.out.println("Enter the pin");
    	double pinn=sc.nextDouble();
    	try {
    		CustomerDetails ccd=walletservice.getEmployeeByPin(accnum, pinn);
    		System.out.println("Enter the amount to be withdrawn");
    		double amt=sc.nextDouble();
    		double bal=ccd.getAccBalance();
    		System.out.println("The old balance in your account was :"+bal);
    		bal-=amt;
    		ccd.setAccBalance(bal);
    		System.out.println("The new balance in your account is :"+ccd.getAccBalance());
    	}catch(WalletException e)
    	{
    		System.err.println("An error occurred : "+e.getMessage());
    	}
    }
    
    public void transferFund()
    {
    	System.out.println("Enter your account number");
    	Long saccnum=sc.nextLong();
    	System.out.println("Enter the pin");
    	double pinn=sc.nextDouble();
    	try {
    		CustomerDetails scd=walletservice.getEmployeeByPin(saccnum, pinn);
    		System.out.println("Enter the account number of the receiver");
    		Long raccnum=sc.nextLong();
    		CustomerDetails rcd=walletservice.getEmployeeByAcc(raccnum);
    		System.out.println("Enter the amount to be transferred");
    		double amount=sc.nextDouble();
    		double samt=scd.getAccBalance();
    		samt-=amount;
    		scd.setAccBalance(samt);
    		double ramt=rcd.getAccBalance();
    		ramt+=amount;
    		rcd.setAccBalance(ramt);
    		System.out.println("Amount transferred successfully");
    	}catch(WalletException e)
    	{
    		System.err.println("An error occurred : "+e.getMessage());
    	}
    }
    
    public void printTransaction()
    {
    	System.out.println("Enter your account number");
    	Long accnum=sc.nextLong();
    	System.out.println("Enter the pin");
    	double pin=sc.nextDouble();
    	try {
    		CustomerDetails cd=walletservice.getEmployeeByPin(accnum, pin);
    		System.out.println("The balance amount in your account is "+cd.getAccBalance());
    	}catch(WalletException e)
    	{
    		System.err.println("An error occurred : "+e.getMessage());
    	}
    }
}
