package com.DB;
import java.util.HashMap;

import com.bean.*;
public class WalletDB {
private static HashMap<Long,CustomerDetails> customerMap=new HashMap<Long,CustomerDetails>();
static {
	customerMap.put(100001l,new CustomerDetails(100001l,"Aishwarya",10000,"Kilpauk","9940680630",1234));
	customerMap.put(100002l,new CustomerDetails(100002l,"Hema",15000,"Shenoy nagar","5656848482",2345));
	customerMap.put(100003l,new CustomerDetails(100003l,"Moni",20000,"Anna nagar","2323459598",3456));
	customerMap.put(100004l,new CustomerDetails(100004l,"Kirthika",8000,"Chetpet","1212456568",4567));
	customerMap.put(100005l,new CustomerDetails(100005l,"Akshaya",40000,"Mogappair","3636221214",5678));
}

public static HashMap<Long,CustomerDetails> getCustomerMap()
{
	return customerMap;
}
}
