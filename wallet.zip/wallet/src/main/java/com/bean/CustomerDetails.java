package com.bean;

public class CustomerDetails {
private String name;
private long accNumber;
private double accBalance;
private String address;
private String mobileNumber;
private double pin;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public long getAccNumber() {
	return accNumber;
}
public void setAccNumber(long accNumber) {
	this.accNumber = accNumber;
}
public double getAccBalance() {
	return accBalance;
}
public void setAccBalance(double accBalance) {
	this.accBalance = accBalance;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(String mobileNumber) {
	this.mobileNumber = mobileNumber;
}

public double getPin() {
	return pin;
}
public void setPin(double pin) {
	this.pin = pin;
}
public CustomerDetails(long accNumber,String name, double accBalance, String address, String mobileNumber,
		double pin) {
	super();
	this.name = name;
	this.accNumber = accNumber;
	this.accBalance = accBalance;
	this.address = address;
	this.mobileNumber = mobileNumber;
	this.pin = pin;
}
public CustomerDetails() {

}
@Override
public String toString() {
	return "CustomerDetails [name=" + name + ", accNumber=" + accNumber + ", accBalance=" + accBalance + ", address="
			+ address + ", mobileNumber=" + mobileNumber+ "]";
}


}
