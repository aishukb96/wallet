package com.dao;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Optional;

import com.DB.WalletDB;
import com.bean.CustomerDetails;
import com.exception.WalletException;

public class WalletDaoImpl implements WalletDao {
static HashMap<Long,CustomerDetails> custMap=WalletDB.getCustomerMap();

@Override
public long addCustomer(CustomerDetails cd) throws WalletException {
	try {
		if(custMap.size()==0)
		{
			cd.setAccNumber(100001); //constant value.
		}
		else
		{
			Optional<Long> id=custMap.keySet().stream().max(new Comparator<Long>() {
			@Override
			public int compare(Long x,Long y)
			{
				return x>y?1:x<y?-1:0;
			}
		});
	long reqnum=id.get()+1;
	cd.setAccNumber(reqnum);
}
		custMap.put(cd.getAccNumber(), cd);
		return cd.getAccNumber();
	}
		catch(Exception ex)
	{
	throw new WalletException(ex.getMessage());
	}
}

@Override
public CustomerDetails getEmployeeByPin(Long accnum,double pin) throws WalletException {
	try
	{
		CustomerDetails c=custMap.get(accnum);
		if(c==null)
		{
			throw new WalletException("customer with the account number "+accnum+" not available in the database");
		}
		if(c.getPin()!=pin)
		{
			throw new WalletException("Pin number is not matching with the account's pin number");
		}
		return c;
	}catch(Exception ex)
	{
		throw new WalletException(ex.getMessage());
	}
}

@Override
public CustomerDetails getEmployeeByAcc(Long accnum) throws WalletException {
	// TODO Auto-generated method stub
	try
	{
		CustomerDetails c=custMap.get(accnum);
		if(c==null)
		{
			throw new WalletException("Customer with this account number not available. Please enter a valid account number");
		}
		return c;
	}catch(Exception ex)
	{
		throw new WalletException(ex.getMessage());
	}
}


}
