package com.service;

import com.bean.CustomerDetails;
import com.dao.WalletDao;
import com.dao.WalletDaoImpl;
import com.exception.WalletException;

public class WalletServiceImpl implements WalletService{
WalletDao walletdao=new WalletDaoImpl();

public boolean validateCustomer(CustomerDetails cust) throws WalletException
{
	if(validateName(cust.getName())&&validateMobNumber(cust.getMobileNumber())&&validateAddress(cust.getAddress())&&validatePin(cust.getPin()))
	{
		return true;
	}
	return false;
}


private boolean validateMobNumber(String mobile) throws WalletException
{
	if(mobile.isEmpty() || mobile==null)
	{
		throw new WalletException("mobile number cannot be empty");
	}
	else
	{
		if(!mobile.matches("\\d{10}"))
				{
			throw new WalletException("Mobile number should contain only 10 digits");
				}
	}
	return true;
}

private boolean validatePin(Double pin) throws WalletException
{
	if(pin==null)
	{
		throw new WalletException("pin cannot be empty");
	}
	
	return true;
}

private boolean validateName(String name) throws WalletException
{
	if(name.isEmpty() || name==null)
	{
		throw new WalletException("customer name cannot be empty");
	}
	else
	{
		if(!name.matches("[A-Z][A-Za-z]{2,}"))
		{
			throw new WalletException("Name should start with a capital letter followed by a minimum of 2 alphabets");
		}
	}
	return true;
}

private boolean validateAddress(String address) throws WalletException
{
	if(address.isEmpty() || address==null)
	{
		throw new WalletException("address cannot be empty");
	}
	else
	{
		if(!address.matches("[A-Z][A-Za-z]{2,}"))
		{
			throw new WalletException("address should start with a capital letter followed by a minimum of 2 alphabets");
		}
	}
	return true;
}

public long addCustomer(CustomerDetails cd) throws WalletException
{
	return walletdao.addCustomer(cd);
}


@Override
public CustomerDetails getEmployeeByPin(Long accnum, double pin) throws WalletException {
	// TODO Auto-generated method stub
	return walletdao.getEmployeeByPin(accnum, pin);
}


@Override
public CustomerDetails getEmployeeByAcc(Long accnum) throws WalletException {
	return walletdao.getEmployeeByAcc(accnum);
}
}
