package com.service;

import com.bean.CustomerDetails;
import com.exception.WalletException;

public interface WalletService {
boolean validateCustomer(CustomerDetails cd) throws WalletException;
long addCustomer(CustomerDetails cd) throws WalletException;
public CustomerDetails getEmployeeByPin(Long accnum,double pin) throws WalletException;
public CustomerDetails getEmployeeByAcc(Long accnum) throws WalletException;


}
